gas_mileage=float(input())
gas_cost=float(input())
gas_cost1=20/gas_mileage*gas_cost
gas_cost2=75/gas_mileage*gas_cost
gas_cost3=500/gas_mileage*gas_cost
print(f'{gas_cost1:.2f} {gas_cost2:.2f} {gas_cost3:.2f}')